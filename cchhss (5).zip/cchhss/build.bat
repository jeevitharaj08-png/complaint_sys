@echo off
echo ===================================================
echo Compiling Complaint Handling System (C11, GCC)...
echo ===================================================
gcc -std=c11 -Wall -Wextra -pedantic -Iinclude -o complaint_system.exe src\main.c
if %ERRORLEVEL% equ 0 (
    echo [SUCCESS] Build completed successfully.
    echo Executable: complaint_system.exe
) else (
    echo [ERROR] Compilation failed!
)
