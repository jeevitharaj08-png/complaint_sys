file(REMOVE_RECURSE
  "libcomplaint_app_core.a"
)
