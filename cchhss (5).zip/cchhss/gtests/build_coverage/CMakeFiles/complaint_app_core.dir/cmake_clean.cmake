file(REMOVE_RECURSE
  "CMakeFiles/complaint_app_core.dir/mnt/c/Users/likhi/OneDrive/Desktop/cchhss/src/main.c.o"
  "CMakeFiles/complaint_app_core.dir/mnt/c/Users/likhi/OneDrive/Desktop/cchhss/src/main.c.o.d"
  "libcomplaint_app_core.a"
  "libcomplaint_app_core.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/complaint_app_core.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
