file(REMOVE_RECURSE
  "CMakeFiles/run_unit_tests.dir/link.d"
  "CMakeFiles/run_unit_tests.dir/test_agent.cpp.o"
  "CMakeFiles/run_unit_tests.dir/test_agent.cpp.o.d"
  "CMakeFiles/run_unit_tests.dir/test_authentication.cpp.o"
  "CMakeFiles/run_unit_tests.dir/test_authentication.cpp.o.d"
  "CMakeFiles/run_unit_tests.dir/test_complaints.cpp.o"
  "CMakeFiles/run_unit_tests.dir/test_complaints.cpp.o.d"
  "CMakeFiles/run_unit_tests.dir/test_customer.cpp.o"
  "CMakeFiles/run_unit_tests.dir/test_customer.cpp.o.d"
  "CMakeFiles/run_unit_tests.dir/test_helpers.cpp.o"
  "CMakeFiles/run_unit_tests.dir/test_helpers.cpp.o.d"
  "CMakeFiles/run_unit_tests.dir/test_main.cpp.o"
  "CMakeFiles/run_unit_tests.dir/test_main.cpp.o.d"
  "CMakeFiles/run_unit_tests.dir/test_manager.cpp.o"
  "CMakeFiles/run_unit_tests.dir/test_manager.cpp.o.d"
  "CMakeFiles/run_unit_tests.dir/test_storage.cpp.o"
  "CMakeFiles/run_unit_tests.dir/test_storage.cpp.o.d"
  "CMakeFiles/run_unit_tests.dir/test_validation.cpp.o"
  "CMakeFiles/run_unit_tests.dir/test_validation.cpp.o.d"
  "run_unit_tests"
  "run_unit_tests.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/run_unit_tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
