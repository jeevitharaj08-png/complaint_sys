# CMake generated Testfile for 
# Source directory: /mnt/c/Users/likhi/OneDrive/Desktop/cchhss/gtests
# Build directory: /mnt/c/Users/likhi/OneDrive/Desktop/cchhss/gtests/build_coverage
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(AllTests "/mnt/c/Users/likhi/OneDrive/Desktop/cchhss/gtests/build_coverage/run_unit_tests")
set_tests_properties(AllTests PROPERTIES  _BACKTRACE_TRIPLES "/mnt/c/Users/likhi/OneDrive/Desktop/cchhss/gtests/CMakeLists.txt;66;add_test;/mnt/c/Users/likhi/OneDrive/Desktop/cchhss/gtests/CMakeLists.txt;0;")
