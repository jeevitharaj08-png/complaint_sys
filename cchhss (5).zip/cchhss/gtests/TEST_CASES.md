# Test Traceability Matrix — Complaint Handling System

This document maps all **29 application functions** to their corresponding automated unit test cases within the Google Test suite. Every function is directly exercised by dedicated tests covering normal execution, boundaries, edge cases, error paths, and loop iterations.

All 114 test cases execute within isolated sandboxes, leaving production data completely unmodified.

---

## Test Traceability Matrix

| Function | Test ID | Scenario | Input and Preconditions | Expected Result | Status |
|---|---|---|---|---|:---:|
| `getTimestamp` (F1) | `TC_VAL_01` | Normal timestamp generation | Valid buffer `char[64]` | Formats datetime string `YYYY-MM-DD HH:MM:SS` (len 19) | **PASS** |
| `getTimestamp` (F1) | `TC_VAL_02` | NULL buffer pointer guard | `buffer = NULL`, `size = 64` | Returns immediately without segmentation fault | **PASS** |
| `getTimestamp` (F1) | `TC_VAL_03` | Zero buffer size guard | `size = 0`, non-empty buffer | Buffer remains unmodified | **PASS** |
| `getTimestamp` (F1) | `TC_VAL_04` | Small buffer size handling | `size = 5` bytes | Handles truncation safely without buffer overflow | **PASS** |
| `getTimestamp` (F1) | `TC_VAL_05` | System `localtime` failure simulation | `g_fail_localtime = 1` mock | Populates destination buffer with `"N/A"` | **PASS** |
| `readString` (F2) | `TC_VAL_06` | Standard line input | Input `"Hello World\n"`, prompt provided | Strips `\n`, prints prompt, buffer has `"Hello World"` | **PASS** |
| `readString` (F2) | `TC_VAL_07` | CRLF newline termination | Input `"Windows Line\r\n"` | Strips both `\r` and `\n` | **PASS** |
| `readString` (F2) | `TC_VAL_08` | Delimiter pipe character sanitization | Input `"user\|data\|injection\|attempt\n"` | Replaces `\|` with `-` (`"user-data-injection-attempt"`) | **PASS** |
| `readString` (F2) | `TC_VAL_09` | NULL and empty prompt display | `prompt = NULL` and `prompt = ""` | Reads input correctly without printing prompt | **PASS** |
| `readString` (F2) | `TC_VAL_10` | NULL buffer and zero size guards | `buffer = NULL` and `size = 0` | Returns immediately without dereferencing NULL | **PASS** |
| `readString` (F2) | `TC_VAL_11` | Immediate EOF on stdin | Simulated stdin exhausted (EOF) | Sets `buffer[0] = '\0'` safely | **PASS** |
| `readString` (F2) | `TC_VAL_12` | Empty input line | Input `"\n"` | Buffer set to empty string `""` | **PASS** |
| `readInt` (F3) | `TC_VAL_13` | Valid integer in range | Input `"3\n"`, range `[1, 5]` | Returns parsed integer `3` | **PASS** |
| `readInt` (F3) | `TC_VAL_14` | Boundary: exact minVal | Input `"1\n"`, range `[1, 10]` | Returns parsed integer `1` | **PASS** |
| `readInt` (F3) | `TC_VAL_15` | Boundary: exact maxVal | Input `"10\n"`, range `[1, 10]` | Returns parsed integer `10` | **PASS** |
| `readInt` (F3) | `TC_VAL_16` | Value below minimum then valid | Input `"0\n2\n"`, range `[1, 5]` | Rejects `0`, prompts retry, returns `2` | **PASS** |
| `readInt` (F3) | `TC_VAL_17` | Value above maximum then valid | Input `"6\n4\n"`, range `[1, 5]` | Rejects `6`, prompts retry, returns `4` | **PASS** |
| `readInt` (F3) | `TC_VAL_18` | Non-numeric string then valid | Input `"invalid\n5\n"`, range `[1, 10]` | Rejects alphabetic input, prompts retry, returns `5` | **PASS** |
| `readInt` (F3) | `TC_VAL_19` | Mixed alphanumeric string then valid | Input `"12abc\n7\n"`, range `[1, 10]` | Rejects trailing non-numeric chars, returns `7` | **PASS** |
| `readInt` (F3) | `TC_VAL_20` | Empty line input then valid | Input `"\n3\n"`, range `[1, 5]` | Rejects empty line, prompts retry, returns `3` | **PASS** |
| `readInt` (F3) | `TC_VAL_21` | EOF on stdin safeguard | Simulated stdin EOF | Returns `minVal` safely without infinite loop | **PASS** |
| `findCustomerByUsername` (F4) | `TC_CUST_01` | NULL and empty username lookup | `username = NULL` and `username = ""` | Returns `NULL` defensively | **PASS** |
| `findCustomerByUsername` (F4) | `TC_CUST_02` | Search in empty customer list | `customerHead = NULL` | Returns `NULL` safely | **PASS** |
| `findCustomerByUsername` (F4) | `TC_CUST_03` | Multi-node list traversal (Head, Mid, Tail, Miss) | 3 customer accounts in linked list | Matches head, middle, tail, returns NULL on missing | **PASS** |
| `findComplaintById` (F5) | `TC_CMP_01` | NULL and empty complaint ID lookup | `complaintId = NULL` and `complaintId = ""` | Returns `NULL` defensively | **PASS** |
| `findComplaintById` (F5) | `TC_CMP_02` | Search in empty complaint list | `complaintHead = NULL` | Returns `NULL` safely | **PASS** |
| `findComplaintById` (F5) | `TC_CMP_03` | Multi-node traversal (Head, Mid, Tail, Miss) | 3 complaints in linked list | Matches head (`CMP101`), mid (`CMP102`), tail (`CMP103`), NULL on missing | **PASS** |
| `addAuditEntry` (F6) | `TC_CMP_04` | NULL node pointer guard | `node = NULL` | Returns safely without dereferencing NULL | **PASS** |
| `addAuditEntry` (F6) | `TC_CMP_05` | Append first and subsequent audit entries | Valid `ComplaintNode`, multiple events | Appends to empty head, then traverses `next` to tail | **PASS** |
| `addAuditEntry` (F6) | `TC_CMP_06` | NULL parameter fallback strings | `action = NULL`, `by = NULL`, `details = NULL` | Defaults to `"ACTION"`, `"SYSTEM"`, `""` | **PASS** |
| `addAuditEntry` (F6) | `TC_CMP_07` | Dynamic memory allocation failure | `g_fail_malloc = 1` mock | Prints allocation error message, `auditHead` remains unchanged | **PASS** |
| `autoAssignAgent` (F7) | `TC_CMP_08` | Zero open workload load balancing | 0 complaints in system | Selects active agent 0 (`AGT101`) with workload 0 | **PASS** |
| `autoAssignAgent` (F7) | `TC_CMP_09` | All 10 agents inactive | `agents[0..9].isActive = 0` | Returns `-1` indicating no active agents available | **PASS** |
| `autoAssignAgent` (F7) | `TC_CMP_10` | Workload balancing with closed tickets | Agent 1 has 2 tickets, Agent 2 has 1 ticket, resolved tickets present | Selects Agent 2 (index 1); resolved/closed tickets excluded | **PASS** |
| `initSystem` (F8) | `TC_STOR_01` | Cold start without data files | Sandbox directory with no files in `data/` | Provisions 10 default agents, counters 101/1001, empty lists | **PASS** |
| `initSystem` (F8) | `TC_STOR_02` | Partial agents file padding | `data/agents.txt` containing only 2 agents | Loads 2 custom agents, pads agents 3-10 with defaults | **PASS** |
| `initSystem` (F8) | `TC_STOR_03` | Corrupt and out-of-range counter handling | Non-numeric and below-minimum values | Corrupt resets to 101/1001; values < 101/1001 clamped | **PASS** |
| `initSystem` (F8) | `TC_STOR_04` | Full load of customers, complaints, audits | Populated text files with linked records | Restores linked lists, updates sequence numbers, links audits | **PASS** |
| `initSystem` (F8) | `TC_STOR_08` | Malformed lines in storage files | Delimiter and parsing errors in files | Skips corrupted lines safely, loads valid records | **PASS** |
| `initSystem` (F8) | `TC_STOR_09` | Malloc failure handling during entity loading | `g_fail_malloc = 1` mock | Handles allocation failures safely without crashing | **PASS** |
| `initSystem` (F8) | `TC_STOR_10` | Audit node malloc failure handling | `g_fail_malloc_audit_only = 1` | Complaint loaded, audit allocation failure skipped | **PASS** |
| `saveAllData` (F9) | `TC_STOR_05` | Normal data flush with fallback placeholders | Complaint with empty timestamps and notes | Persists records; writes `"N/A"` and `"No notes yet"` | **PASS** |
| `saveAllData` (F9) | `TC_STOR_06` | File open failure handling | `g_fail_fopen = 1` mock | Handles NULL file pointer safely on disk write failures | **PASS** |
| `freeAllMemory` (F10) | `TC_STOR_07` | Deallocation on empty and populated lists | Linked lists populated with customers, complaints, audits | Frees all nodes, resets `customerHead` and `complaintHead` to NULL | **PASS** |
| `customerMenu` (F11) | `TC_CUST_04` | Direct menu exit | Choice `3` (Return to main menu) | Returns cleanly to caller | **PASS** |
| `customerMenu` (F11) | `TC_CUST_05` | Navigate registration submenu then exit | Choice `1` (Register), blank name, Choice `3` | Launches registration workflow then returns | **PASS** |
| `customerMenu` (F11) | `TC_CUST_06` | Navigate login submenu then exit | Choice `2` (Login), invalid creds, Choice `3` | Launches login workflow then returns | **PASS** |
| `customerRegister` (F12) | `TC_CUST_07` | Blank full name validation | Input `"\n"` | Aborts with `"Full name cannot be blank"` | **PASS** |
| `customerRegister` (F12) | `TC_CUST_08` | Blank username validation | Input `"John Doe\n\n"` | Aborts with `"Username cannot be blank"` | **PASS** |
| `customerRegister` (F12) | `TC_CUST_09` | Duplicate username uniqueness enforcement | Existing user `"johndoe"` in system | Rejects with `"Username ... is already taken"` | **PASS** |
| `customerRegister` (F12) | `TC_CUST_10` | Blank password validation | Input `"Name\nuser\n\n"` | Aborts with `"Password cannot be blank"` | **PASS** |
| `customerRegister` (F12) | `TC_CUST_11` | Blank contact details validation | Input `"Name\nuser\npass\n\n"` | Aborts with `"Contact details cannot be blank"` | **PASS** |
| `customerRegister` (F12) | `TC_CUST_12` | Success path for 1st, 2nd, 3rd customers | Sequential valid registration inputs | Assigns `CUST1001`, `CUST1002`, `CUST1003`, loops to tail | **PASS** |
| `customerRegister` (F12) | `TC_CUST_13` | Memory allocation failure path | `g_fail_malloc = 1` mock | Prints allocation failure message, aborts cleanly | **PASS** |
| `customerLogin` (F13) | `TC_AUTH_01` | Successful customer authentication | Valid username `"johndoe"`, password `"pass123"` | Launches dashboard, displays welcome message | **PASS** |
| `customerLogin` (F13) | `TC_AUTH_02` | Non-existent customer username | Non-existent username `"nosuchuser"` | Prints `"Authentication failed"` | **PASS** |
| `customerLogin` (F13) | `TC_AUTH_03` | Valid username with wrong password | Username `"johndoe"`, password `"wrongpass"` | Prints `"Authentication failed"` | **PASS** |
| `customerDashboard` (F14) | `TC_CUST_14` | Direct logout from customer dashboard | Choice `5` (Logout) | Prints logout message, terminates dashboard loop | **PASS** |
| `customerDashboard` (F14) | `TC_CUST_15` | Menu dispatch to subfunctions | Choices `1`, `2`, `3`, `4`, then `5` | Dispatches register, view, track, history handlers | **PASS** |
| `customerRegisterComplaint` (F15) | `TC_CMP_11` | Blank complaint description validation | Category `1`, Priority `2`, empty description | Aborts with `"Description cannot be empty"` | **PASS** |
| `customerRegisterComplaint` (F15) | `TC_CMP_12` | Success path with active agent auto-assign | Valid category, priority, description | Creates `CMP101`, status `ASSIGNED`, agent `AGT101`, logs audit | **PASS** |
| `customerRegisterComplaint` (F15) | `TC_CMP_13` | Success path with no active agents | All agents inactive | Creates `CMP101`, status `PENDING`, agent `UNASSIGNED` | **PASS** |
| `customerRegisterComplaint` (F15) | `TC_CMP_14` | ID collision avoidance while loop | Existing complaint `CMP102` | Advances past collision to `CMP103` | **PASS** |
| `customerRegisterComplaint` (F15) | `TC_CMP_15` | Multi-node complaint list append | 3 sequential complaint filings | Appends node 1 (`head`), node 2, node 3 via `curr->next` | **PASS** |
| `customerRegisterComplaint` (F15) | `TC_CMP_16` | Memory allocation failure handling | `g_fail_malloc = 1` mock | Prints allocation error message, aborts cleanly | **PASS** |
| `customerViewComplaints` (F16) | `TC_CUST_16` | Customer with zero complaints | Customer with no filed tickets | Prints `"No complaints found under your account"` | **PASS** |
| `customerViewComplaints` (F16) | `TC_CUST_17` | Multiple complaints and cross-customer isolation | Tickets for `CUST1001` and `CUST1002` | Renders `CUST1001` tickets; strictly omits `CUST1002` tickets | **PASS** |
| `customerTrackComplaint` (F17) | `TC_CUST_18` | Complaint ID not found | ID `"CMP999"` | Prints `"Error: Complaint ID 'CMP999' not found"` | **PASS** |
| `customerTrackComplaint` (F17) | `TC_CUST_19` | Cross-customer tracking access violation | Customer `CUST1001` queries ticket belonging to `CUST1002` | Prints `"Security violation"` and aborts | **PASS** |
| `customerTrackComplaint` (F17) | `TC_CUST_20` | Full stage progression coverage | Complaints in all 7 status states | Displays stage indicators 1/5, 2/5, 3/5, 3.5/5, 4/5, 5/5, custom | **PASS** |
| `customerViewHistory` (F18) | `TC_CUST_21` | Complaint ID not found | ID `"CMP999"` | Prints `"Error: Complaint ID 'CMP999' not found"` | **PASS** |
| `customerViewHistory` (F18) | `TC_CUST_22` | Cross-customer audit history violation | Customer attempts viewing another customer's ticket audit | Prints `"Security violation"` and aborts | **PASS** |
| `customerViewHistory` (F18) | `TC_CUST_23` | Complaint with zero audit entries | Valid complaint node with `auditHead = NULL` | Prints `"No audit records found for this complaint"` | **PASS** |
| `customerViewHistory` (F18) | `TC_CUST_24` | Chronological audit history trail display | Complaint with multiple audit records | Prints chronological table with timestamps and details | **PASS** |
| `agentMenu` (F19) | `TC_AUTH_04` | Return to main menu | Choice `2` (Return) | Exits portal loop cleanly | **PASS** |
| `agentMenu` (F19) | `TC_AUTH_05` | Valid agent username with wrong password | Username `"agent1"`, password `"wrongpass"` | Fails authentication, displays error message | **PASS** |
| `agentMenu` (F19) | `TC_AUTH_06` | Inactive agent login denial | Valid credentials for inactive agent | Denies access with `"account is currently set to Inactive"` | **PASS** |
| `agentMenu` (F19) | `TC_AUTH_07` | Successful agent login and logout | Valid credentials for active agent | Launches `agentDashboard()`, logs out cleanly | **PASS** |
| `agentDashboard` (F20) | `TC_AGT_01` | Workload calculation (Active vs Closed) | Tickets with ASSIGNED, RESOLVED, CLOSED, other agent | Calculates live workload counting only open tickets for agent | **PASS** |
| `agentDashboard` (F20) | `TC_AGT_02` | Audit history lookup (found vs not found) | Choice `3`, non-existent ID then valid ID | Handles missing ticket and renders audit history | **PASS** |
| `agentDashboard` (F20) | `TC_AGT_03` | Menu dispatch to view assigned and update | Choices `1`, `2` (cancelled), `4` (logout) | Dispatches operational tools | **PASS** |
| `agentViewAssigned` (F21) | `TC_AGT_04` | Zero complaints assigned to agent | Agent with 0 assigned tickets | Prints `"No complaints are currently assigned to you"` | **PASS** |
| `agentViewAssigned` (F21) | `TC_AGT_05` | Multiple assigned tickets filtering | Multiple complaints in system | Lists complaints for this agent; excludes other agents | **PASS** |
| `agentUpdateComplaint` (F22) | `TC_AGT_06` | Complaint ID not found | ID `"CMP999"` | Prints `"Error: Complaint ID 'CMP999' not found"` | **PASS** |
| `agentUpdateComplaint` (F22) | `TC_AGT_07` | Ticket assigned to a different agent | Agent `AGT101` updates ticket assigned to `AGT102` | Rejects with `"is not assigned to you"` | **PASS** |
| `agentUpdateComplaint` (F22) | `TC_AGT_08` | Action cancellation | Choice `4` (Cancel) | Aborts with `"Action cancelled"`, no state change | **PASS** |
| `agentUpdateComplaint` (F22) | `TC_AGT_09` | Progress to IN_PROGRESS with default note | Choice `1`, empty note `"\n"` | Sets status `IN_PROGRESS`, default note `"Status updated by AGT101"` | **PASS** |
| `agentUpdateComplaint` (F22) | `TC_AGT_10` | Progress to RESOLVED and metric increment | Choice `2`, resolution note | Sets status `RESOLVED`, sets timestamp, increments `resolvedCount` | **PASS** |
| `agentUpdateComplaint` (F22) | `TC_AGT_11` | Progress to ESCALATED | Choice `3`, escalation note | Sets status `ESCALATED`, sets timestamp, logs audit event | **PASS** |
| `agentUpdateComplaint` (F22) | `TC_AGT_12` | Progress to RESOLVED by second agent (`AGT102`)| Choice `2`, agent index > 0 | Matches agent index loop, increments `resolvedCount` | **PASS** |
| `agentUpdateComplaint` (F22) | `TC_AGT_13` | Unknown agent ID loop exhaustion | Unlisted agent identifier | Exhausts 10-agent loop condition `i < MAX_AGENTS` | **PASS** |
| `managerMenu` (F23) | `TC_AUTH_08` | Return to main menu | Choice `2` (Return) | Exits portal loop cleanly | **PASS** |
| `managerMenu` (F23) | `TC_AUTH_09` | Non-existent manager username | Username `"wrongadmin"`, password `"wrongpass"` | Prints `"Authentication failed"` | **PASS** |
| `managerMenu` (F23) | `TC_AUTH_10` | Valid manager user with wrong password | Username `"manager"`, password `"wrongpass"` | Prints `"Authentication failed"` | **PASS** |
| `managerMenu` (F23) | `TC_AUTH_11` | Successful manager authentication | Username `"manager"`, password `"manager123"` | Launches `managerDashboard()`, logs out cleanly | **PASS** |
| `managerDashboard` (F24) | `TC_MGR_01` | Direct logout from manager dashboard | Choice `6` (Logout) | Prints logout message, terminates dashboard loop | **PASS** |
| `managerDashboard` (F24) | `TC_MGR_02` | Dispatches all administrative tools | Choices `1`, `2`, `3`, `4`, `5` (empty), `6` | Dispatches view, assign, update, agent mgmt, audit tools | **PASS** |
| `managerDashboard` (F24) | `TC_MGR_03` | View complete audit history with events | Choice `5`, populated audit events | Renders complete cross-system chronological audit table | **PASS** |
| `managerViewAllComplaints` (F25) | `TC_MGR_04` | System with zero complaints | 0 complaints in database | Displays all KPIs as 0, prints `"Zero complaints exist"` | **PASS** |
| `managerViewAllComplaints` (F25) | `TC_MGR_05` | Full metrics KPI calculation across all statuses | Complaints in PENDING, ASSIGNED, IN_PROGRESS, RESOLVED, CLOSED, ESCALATED, custom | Accurately aggregates KPIs for each status category | **PASS** |
| `managerAssignComplaint` (F26) | `TC_MGR_06` | Complaint ID not found | ID `"CMP999"` | Prints `"Error: Complaint ID 'CMP999' not found"` | **PASS** |
| `managerAssignComplaint` (F26) | `TC_MGR_07` | Target agent ID does not exist | Agent ID `"AGT999"` | Prints `"Error: Agent ID 'AGT999' does not exist"` | **PASS** |
| `managerAssignComplaint` (F26) | `TC_MGR_08` | Target agent is inactive | Target agent `isActive = 0` | Aborts with `"Agent ... is inactive. Reassignment aborted"` | **PASS** |
| `managerAssignComplaint` (F26) | `TC_MGR_09` | Assignment and reassignment workflow | PENDING ticket to `AGT101`, ASSIGNED ticket to `AGT102` | PENDING promoted to ASSIGNED; reassignments logged | **PASS** |
| `managerUpdateComplaint` (F27) | `TC_MGR_10` | Complaint ID not found | ID `"CMP999"` | Prints `"Error: Complaint ID 'CMP999' not found"` | **PASS** |
| `managerUpdateComplaint` (F27) | `TC_MGR_11` | Action cancellation | Choice `5` (Cancel) | Aborts with `"Action cancelled"` without modifying state | **PASS** |
| `managerUpdateComplaint` (F27) | `TC_MGR_12` | All managerial status transitions | Choices `1` (IN_PROGRESS), `2` (RESOLVED), `3` (CLOSED), `4` (ESCALATED) | Sets statuses, timestamps, default notes, audit entries | **PASS** |
| `managerAgentManagement` (F28) | `TC_MGR_13` | Return to manager menu | Choice `2` (Return) | Exits agent management loop cleanly | **PASS** |
| `managerAgentManagement` (F28) | `TC_MGR_14` | Toggle non-existent agent ID | Agent ID `"AGT999"` | Prints `"Error: Agent ID 'AGT999' not found"` | **PASS** |
| `managerAgentManagement` (F28) | `TC_MGR_15` | Toggle agent ACTIVE to INACTIVE and back | Agent `AGT101` | Toggles `isActive` from 1 to 0, then 0 to 1, saves to disk | **PASS** |
| `main` (F29) | `TC_MAIN_01` | Direct application shutdown | Main menu Choice `4` (Exit) | Flushes state, frees memory, returns exit code 0 | **PASS** |
| `main` (F29) | `TC_MAIN_02` | Navigate Customer menu from main menu | Main menu Choice `1`, return `3`, exit `4` | Dispatches `customerMenu()`, returns and terminates cleanly | **PASS** |
| `main` (F29) | `TC_MAIN_03` | Navigate Agent menu from main menu | Main menu Choice `2`, return `2`, exit `4` | Dispatches `agentMenu()`, returns and terminates cleanly | **PASS** |
| `main` (F29) | `TC_MAIN_04` | Navigate Manager menu from main menu | Main menu Choice `3`, return `2`, exit `4` | Dispatches `managerMenu()`, returns and terminates cleanly | **PASS** |

---
